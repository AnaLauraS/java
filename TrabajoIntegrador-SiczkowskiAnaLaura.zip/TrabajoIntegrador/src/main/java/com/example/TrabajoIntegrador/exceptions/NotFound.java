package com.example.TrabajoIntegrador.exceptions;

public class NotFound extends Exception{
    public NotFound (String m){
        super(m);
    }
}